export const modalGenerator = (modalTitle, modalBody, modalFooter) => {
    return `<div class="modal" tabIndex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${modalTitle ?? null}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${modalBody ?? null}
                </div>
                <div class="modal-footer">
                    ${modalFooter ?? null}
                </div>
            </div>
        </div>
    </div>`
}