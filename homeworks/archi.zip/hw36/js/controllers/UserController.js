class UserController{
    model = null;
    view = null;
    constructor(model, view) {
        this.model = model;
        this.view = view;
    }
    async init(){
        document.addEventListener('DOMContentLoaded', async () => {
            const users = await this.model.getAll();
            this.view.renderTable(await users);
            this.view.createUserTrigger.addEventListener('click', () => this.#handleAddClick);
            this.view.actions.addEventListener('click', (event) => {
                if(event.target.attributes.getNamedItem(`data-edit-user`)){
                    const id = event.target.attributes.getNamedItem(`data-edit-user`).value;
                    this.#handleEditClick(id);
                }else if(event.target.attributes.getNamedItem(`data-delete-user`)){
                    const id = event.target.attributes.getNamedItem(`data-delete-user`).value;
                    this.#handleDeleteClick(id);
                }
            })
        })
    }
    #handleAddClick(){
        this.view.openCreateModal();
        this.view.createUserForm.addEventListener('submit', () => this.#handleCreateSubmit);
    }
    #handleCreateSubmit(){
        event.preventDefault();
        const formData = new FormData(this.view.createUserForm);
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            company: formData.get('company'),
            id: crypto.randomUUID()
        };
        this.model.create(data);
        location.reload();
    }
    #handleEditClick(id){
        const user = this.model.users.find(user => user.id === id);
        this.view.openEditModal(user);
        this.view.editUserForm.addEventListener('submit', () => this.#handleEditSubmit);
    }
    #handleEditSubmit(){
        event.preventDefault();
        const formData = new FormData(this.view.editUserForm);
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            company: formData.get('company'),
            id: crypto.randomUUID()
        }
        this.model.update(user.id, data);
        location.reload();
    }
    #handleDeleteClick(id){
        const user = this.model.users.find(user => user.id === id);
        this.view.openDeleteModal(user);
        this.view.confirmDeleteUserTrigger.addEventListener('click', () => this.#handleDeleteConfirm(id));
    }
    #handleDeleteConfirm(id){
        this.model.delete(id);
        location.reload();
    }
}
export default UserController;