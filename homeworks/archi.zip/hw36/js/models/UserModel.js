import {BASE_URL, ENDPOINTS} from "../config/api.js"

class UserModel {
    users = [];
    constructor() {
        this.users = this.getAll();
    }

    #fetchGetAllUsers = async () => {
        try{
            const response = await fetch(`${BASE_URL}${ENDPOINTS.USERS}`)
            const data = await response.json();
            return data;
        }catch (e){
            throw new Error(e.message);
        }
    }
    #fetchCreateUser = async (userData) => {
        try{
            const response = await fetch(`${BASE_URL}${ENDPOINTS.USERS}`, {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(userData),
            });
            if(!response.ok) throw new Error(response.statusText);
        }catch (e){
            throw new Error(e.message);
        }
    }
    #fetchUpdateUser = async (id, userData) => {
        try{
            const response = await fetch(`${BASE_URL}${ENDPOINTS.USER_BY_ID(id)}`, {
                method: "PUT",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(id, userData),
            });
            if(!response.ok) throw new Error(response.statusText);
        }catch (e){
            throw new Error(e.message);
        }
    }
    #fetchDeleteUser = async (id) => {
        try {
            const response = await fetch(`${BASE_URL}${ENDPOINTS.USER_BY_ID(id)}`, {
                method: "PUT",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(id),
            });
            if(!response.ok) throw new Error(response.statusText);
        }catch (e){
            throw new Error(e.message);
        }
    }
    
    async getAll(){
        const users = await this.#fetchGetAllUsers();
        this.users = users;
        console.log(this.users)
        return this.users;
    }
    async create(userData){
        await this.#fetchCreateUser(userData);
        this.users.push(userData);
    }
    async update(id, userData){
        await this.#fetchUpdateUser(id, userData);
        this.users.forEach(user => {
            if (user.id === id) {
                users[user.id] = userData;
            }
        });    }
    async delete(id){
        await this.#fetchDeleteUser(id);
        this.users = this.users.filter(user => user.id !== id);
    }
}
export default UserModel;